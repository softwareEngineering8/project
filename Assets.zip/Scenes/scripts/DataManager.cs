﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class DataManager : MonoBehaviour
{
    public static DataManager dm = null;
    public List<TempVacation> vacaList;

    // Start is called before the first frame update
    void Start()
    {
        dm = transform.GetComponent<DataManager>();

        vacaList = new List<TempVacation>();


        DateTime departDate = new DateTime(2020, 1, 1);
        DateTime arriveDate = new DateTime(2020, 1, 5);

        int vacakind = 0; //[0] : general [1]: specialvacation

        vacaList.Add(new TempVacation("person", vacakind, departDate, arriveDate,0,"vacationName"));



        
        for (int i=0;i<500;i++)
        {
            DateTime baseDate = new DateTime(2020, 1, 1);

            DateTime randDepartDate = baseDate.AddDays(UnityEngine.Random.Range(0, 360));
            // randDepartDate = new DateTime(2020, month, day);  u can also use this to add vacation info

            int randPeriod = UnityEngine.Random.Range(3, 6);
            DateTime randArriveDate = randDepartDate.AddDays(randPeriod);
            int vacaKind = UnityEngine.Random.Range(0, 2);

            vacaList.Add(new TempVacation("soldier"+i.ToString(),vacaKind, randDepartDate, randArriveDate, 0, "vacationName"));
        }
        
            
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}