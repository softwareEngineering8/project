﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Soldiers 
{
   
    public user soldid;
   
}

[System.Serializable]
public class sold
{
    public string nam, soldnu, birt, affiliatio, phon,id,pass;
}
