﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
public class Screen3 : MonoBehaviour
{
    int week;
    DateTime baseDate = new DateTime(2019, 12, 31);
    DateTime startDate;
    DateTime endDate;
    List<GameObject> tableList;
    [SerializeField] Text[] date_Texts;
    [SerializeField] Text inputWeek;
    [SerializeField] Text weekText;
    [SerializeField] GameObject tableObject;
    [SerializeField] GameObject tablePanel;
    [SerializeField] GameObject tableResult;
    
    public DataManager dm;

    int[] daycount = new int[14];

    // Start is called before the first frame update
    void Start()
    {
        tableList = new List<GameObject>();

        do
        {
            dm = DataManager.dm;
        } while (DataManager.dm == null);//get Data

        DateSet(24);
    }

    void RefreshTable()
    {
        while(tableList.Count>0)
        {            
            Destroy(tableList[0]);
            tableList.RemoveAt(0);
        }

        int checkednum = 0;
        int num = dm.vacaList.Count;

        GameObject obj;
        RectTransform rt;

        for (int j = 0; j < 14; j++)        
            daycount[j] = 0;

            for (int i = 0; i < num; i++)
        {
            int comp1 = DateTime.Compare(startDate, dm.vacaList[i].arriveDate);
            int comp2 = DateTime.Compare(dm.vacaList[i].departDate, endDate);
            if (comp1<0 && comp2<0)
            {
                obj = Instantiate(tableObject, transform.position, transform.rotation);
                
                obj.transform.SetParent(tablePanel.transform);

                TimeSpan ts = dm.vacaList[i].departDate - startDate;
                int startDate_int = ts.Days;
                int period = dm.vacaList[i].getPeriod();

                Screen3_Table tt = obj.GetComponent<Screen3_Table>();
                tt.set_Screen3_Table(dm.vacaList[i].soldierName, startDate_int, period, dm.vacaList[i].departDate, dm.vacaList[i].arriveDate);
                tableList.Add(obj);
                checkednum++;

                for (int j=Mathf.Max(0, startDate_int); j< Mathf.Min(14,startDate_int+period);j++)                
                    daycount[j]++;                
            }
            
        }

        obj = Instantiate(tableResult, transform.position, transform.rotation);
        tableList.Add(obj);
        obj.transform.SetParent(tablePanel.transform);
        for (int i = 0; i < 14; i++)
            obj.transform.GetChild(1).GetChild(i).GetChild(0).GetComponent<Text>().text = daycount[i].ToString();

        print(checkednum);
        rt = (RectTransform)tablePanel.transform.parent;
        rt.sizeDelta = new Vector2(0, 23.1072f * (checkednum+1));

    }

    void DateSet(int _week)
    {
        week = _week;
        weekText.text = week.ToString() +"~"+ (week + 1).ToString() +"th week vacation calender";

        startDate = baseDate.AddDays((week - 1) * 7);
        endDate = startDate.AddDays(14);
        for(int i=0;i<14;i++)
        {
            DateTime tempDate = startDate.AddDays(i);
            date_Texts[i].text = tempDate.Month + "/" + tempDate.Day;
        }

        RefreshTable();
    }

    public void clickSearchButton()
    {
        if (0 < int.Parse(inputWeek.text) && int.Parse(inputWeek.text) < 53)
            DateSet(int.Parse(inputWeek.text));
    }
}
