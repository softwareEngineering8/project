﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TempSoldier
{
    public string soldierName;
    public string soldierNumber;

    public TempSoldier(string _name, string _number)
    {
        soldierName = _name;
        soldierNumber = _number;
    }
}
