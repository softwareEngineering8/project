﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class SoldierScreen2A : MonoBehaviour
{
    [SerializeField] GameObject Screen2A_table;
    [SerializeField] GameObject AddTableButton;
    List<GameObject> tableList;
    SoldierDataManager sdm = null;
    int num;

    // Start is called before the first frame update
    void Start()
    {
        num = 0;
        tableList = new List<GameObject>();
        tableList.Add(transform.GetChild(1).gameObject);

        do
        {
            sdm = SoldierDataManager.sdm;
        } while (sdm == null);

        //refresh();
    }

    // Update is called once per frame
    void Update()
    {
       
    }

    public void refresh()
    {

    }

    public void onClickAddNewTable()
    {
        num++;
        GameObject obj;
        RectTransform rt;

        obj = Instantiate(Screen2A_table,transform);
        obj.transform.SetParent(this.transform);

        tableList.Add(obj);

        rt = (RectTransform)obj.transform;
        rt.anchoredPosition = new Vector2(-12.65f, 197 - 124*num);

        rt = (RectTransform)AddTableButton.transform;
        rt.anchoredPosition = new Vector2(-12.65f, 197 - 124 * (num+1));
    }

    public void pushApply()
    {
        List<TempVacation> list = new List<TempVacation>();
        String _soldierName;
        int _vacaKind;
        DateTime _departTime;
        DateTime _arriveTime;
        int _usedCheck = 0;
        String _vacaName;

        for (int i=0;i<tableList.Count;i++)
        {
            _soldierName = sdm.soldier.name;

            SoldierScreen2_table s2table = tableList[i].GetComponent<SoldierScreen2_table>();
            _vacaKind = s2table.GetvacaKind();
            _departTime = s2table.GetDepartDate();
            _arriveTime = s2table.GetArriveDate();
            _vacaName = s2table.GetvacaName();
            
            list.Add(new TempVacation(_soldierName, _vacaKind, _departTime, _arriveTime, _usedCheck, _vacaName));//add vacation

            print(list[i]);
        }

    }
}
