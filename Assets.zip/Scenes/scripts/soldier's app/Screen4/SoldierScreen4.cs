﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class SoldierScreen4 : MonoBehaviour
{
    [SerializeField] GameObject content;
    [SerializeField] GameObject SoldierScreen4_table;
    [SerializeField] Text allUsedVaca_Text;
    List<GameObject> SoldierScreen4Tables;
    SoldierDataManager sdm = null;
    
    void Start()
    {
        SoldierScreen4Tables = new List<GameObject>();
        
        do
        {
            sdm = SoldierDataManager.sdm;
        } while (sdm == null);

        Refresh();
    }

    // Update is called once per frame
    void Update()
    {

    }

    void Refresh()
    {
        int num = SoldierScreen4Tables.Count;
        for (int i = 0; i < num; i++)
        {
            Destroy(SoldierScreen4Tables[0].gameObject);
            SoldierScreen4Tables.RemoveAt(0);
        }

        int allvaca = 0;

        GameObject obj;
        RectTransform rt;
        for (int i = 0; i < sdm.vacaList.Count; i++)
        {
            if (sdm.vacaList[i].usedCheck == 2) // [0]: notUsed  [1]: waiting for Accept [2]: Used
            {
                obj = Instantiate(SoldierScreen4_table, transform);                
                obj.transform.SetParent(content.transform);

                obj.GetComponent<SoldierScreen4_table>().setSoldierScreen4_table(sdm.vacaList[i]);
                SoldierScreen4Tables.Add(obj);

                rt = (RectTransform)obj.transform;
                rt.anchoredPosition = new Vector2(-8, -68f - 114.7f * (SoldierScreen4Tables.Count - 1));

                allvaca += sdm.vacaList[i].getPeriod();
            }
        }

        rt = (RectTransform)content.transform;
        rt.sizeDelta = new Vector2(0, 120f * (SoldierScreen4Tables.Count));

        allUsedVaca_Text.text = "You have used " + allvaca.ToString() + "days of vacation";
    }
}
