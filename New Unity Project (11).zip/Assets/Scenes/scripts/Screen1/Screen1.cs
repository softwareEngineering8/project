﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Screen1 : MonoBehaviour
{
    [SerializeField] GameObject content;
    [SerializeField] GameObject soldierButton;
    [SerializeField] GameObject addnewSoldierButton;
    [SerializeField] GameObject SoldierInfoScreen;
    [SerializeField] GameObject SoldierInfoScreen_Home;
    [SerializeField] GameObject SoldierInfoScreen_ScreenA;
    [SerializeField] GameObject SoldierInfoScreen_ScreenB;
    [SerializeField] GameObject SoldierInfoScreen_ScreenC;
    [SerializeField] GameObject SoldierInfoScreen_ScreenD;
    public static Screen1 scr;

    int num = 20;

    void Start()
    {
        scr = transform.GetComponent<Screen1>();
        createButtons(num);

        RectTransform rt = (RectTransform)content.transform;
        rt.anchoredPosition = new Vector2(0, 0);
    }

    void Update()
    {
        
    }

    void createButtons(int num)
    {
        GameObject obj;
        RectTransform rt;

        for (int i=0; i<num; i++)
        {
            obj = Instantiate(soldierButton,transform.position,transform.rotation);

            obj.transform.SetParent(content.transform);
            rt = (RectTransform)obj.transform;
            rt.anchoredPosition = new Vector2(-375f + 107f*(i%8),338.7f - 145.7f*(int)(i/8));
            
            Screen1_Button bb = obj.transform.GetChild(0).GetComponent<Screen1_Button>();            
            bb.setButton(i, "name", "affiliation", transform.GetComponent<Screen1>());
            
        }

        obj = Instantiate(addnewSoldierButton, transform.position, transform.rotation);

        obj.transform.SetParent(content.transform);
        rt = (RectTransform)obj.transform;
        rt.anchoredPosition = new Vector2(-375f + 107f * (num % 8), 338.7f - 145.7f * (int)(num / 8));

        Screen1_Add_new add_button = obj.transform.GetComponent<Screen1_Add_new>();
        add_button.setButton(transform.GetComponent<Screen1>());
    }

    public void soldierButtonClick(int num)
    {
        SoldierInfoScreen.SetActive(true);
        SoldierInfoScreen_Home.SetActive(true);
        SoldierInfoScreen_ScreenA.SetActive(false);
        SoldierInfoScreen_ScreenB.SetActive(false);
        SoldierInfoScreen_ScreenC.SetActive(false);
        SoldierInfoScreen_ScreenD.SetActive(false);
    }

    public void soldierInfo_Home_BackButton()
    {
        SoldierInfoScreen.SetActive(false);
    }

    public void soldierInfo_Home_Button1()
    {
        SoldierInfoScreen_Home.SetActive(false);
        SoldierInfoScreen_ScreenA.SetActive(true);
    }

    public void soldierInfo_Home_Button2()
    {
        SoldierInfoScreen_Home.SetActive(false);
        SoldierInfoScreen_ScreenB.SetActive(true);
    }

    public void soldierInfo_Home_Button3()
    {
        SoldierInfoScreen_Home.SetActive(false);
        SoldierInfoScreen_ScreenC.SetActive(true);
    }

    public void soldierInfo_Add_Soldier()
    {
        SoldierInfoScreen.SetActive(true);
        SoldierInfoScreen_Home.SetActive(false);
        SoldierInfoScreen_ScreenD.SetActive(true);
    }

    public void soldierInfo_ScreenA_BackButton()
    {
        SoldierInfoScreen_ScreenA.SetActive(false);
        SoldierInfoScreen_Home.SetActive(true);        
    }

    public void soldierInfo_ScreenB_BackButton()
    {
        SoldierInfoScreen_ScreenB.SetActive(false);
        SoldierInfoScreen_Home.SetActive(true);
    }

    public void soldierInfo_ScreenC_BackButton()
    {
        SoldierInfoScreen_ScreenC.SetActive(false);
        SoldierInfoScreen_Home.SetActive(true);
    }

    public void soldierInfo_ScreenD_BackButton()
    {
        SoldierInfoScreen_ScreenD.SetActive(false);
        SoldierInfoScreen_Home.SetActive(true);
        SoldierInfoScreen.SetActive(false);
    }

}
